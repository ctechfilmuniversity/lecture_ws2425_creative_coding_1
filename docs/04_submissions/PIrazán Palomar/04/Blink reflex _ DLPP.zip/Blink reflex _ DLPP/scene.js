import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {RGBELoader} from 'three/examples/jsm/loaders/RGBELoader.js';

// SCENE
const scene = new THREE.Scene();

// CAMERA
const fov = 45;
const aspect = window.innerWidth / window.innerHeight;
const near = 0.1;
const far = 20000;
const camera = new THREE.PerspectiveCamera(fov, aspect, near, far);

// RENDERER
const canvas = document.querySelector("#canvasThree");
const renderer = new THREE.WebGLRenderer({canvas, antialias: true});
renderer.setSize( window.innerWidth, window.innerHeight);

// CONTROLS FOR NAVIGATION
const controls = new OrbitControls(camera, canvas);
camera.position.set(2,2,9); // Adjust the camera position as needed

// Renderer settings for HDR
renderer.outputEncoding = THREE.sRGBEncoding; 
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.4; // Adjust exposure for better tone mapping



// Load HDR image using RGBELoader
const hdriLoader = new RGBELoader();
hdriLoader.load('img/lake.hdr', function(texture){
    console.log(texture); // Check if the HDR image loads correctly
    texture.mapping = THREE.EquirectangularReflectionMapping;
    scene.background = texture;
    scene.environment = texture;

    //create transparent bubble
    const sphere = new THREE.Mesh(
        new THREE.SphereGeometry(1,50,50),
        new THREE.MeshPhysicalMaterial({
            roughness: 0,
            metalness: 0,
            transmission: 1,
            ior: 3.0, //increase visibility of the reflection on the surface on the sphere


        })
    );


    scene.add(sphere);

    //create transparent ring
    const ringGeometry = new THREE.Mesh(
        new THREE.RingGeometry(3 ,4,50),
        new THREE.MeshPhysicalMaterial({
            roughness: 0,
            metalness: 0,
            transmission: 1,
            ior: 3.0, //increase visibility of the reflection on the surface on the sphere


        })
    );


    scene.add(ringGeometry);

    //create transparent ring2
    const ring2Geometry = new THREE.Mesh(
        new THREE.RingGeometry(3 ,4,50),
        new THREE.MeshPhysicalMaterial({
            roughness: 0,
            metalness: 0,
            transmission: 1,
            ior: 3.0, //increase visibility of the reflection on the surface on the sphere


        })
    );

    ring2Geometry.rotation.x = 1.5;
    scene.add(ring2Geometry);

});




// RENDERING
function renderLoop() {

    renderer.render(scene, camera);
    requestAnimationFrame(renderLoop);
}
renderLoop();
